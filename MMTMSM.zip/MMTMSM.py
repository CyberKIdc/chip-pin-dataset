import cv2
import numpy as np
import onnxruntime as ort
import math
from ultralytics import YOLO

def detect_objects(model_path,image_path):
    """Perform object detection using the ONNX model."""
    model = YOLO(model_path)
    detections = model(image_path)
    for m in detections:
        box = m.boxes
        xyxy= box.xyxy

    detections= xyxy.detach().cpu().numpy().astype(int)


    # Example: detections output format [x_min, y_min, x_max, y_max, score]
    # This needs to be adapted based on your specific model's output
    return detections

def HEIF(object_image):
    cropped_image = object_image

    row_num = cropped_image.shape[0]
    col_num = cropped_image.shape[1]

    nineble_picture = np.zeros((3 * row_num, 3 * col_num))

    for k in range(row_num):
        for m in range(col_num):  # 

            k1 = 3 * k
            k2 = 3 * (k + 1)
            m1 = 3 * m
            m2 = 3 * (m + 1)
            nineble_picture[k1:k2, m1:m2] = np.full((3, 3), cropped_image[k][m])

    h = nineble_picture.shape[0]
    w = nineble_picture.shape[1]

    pixelnum_token = np.zeros((1, 224))

    for h0 in range(h):
        for w0 in range(w):
            pixel = nineble_picture[h0][w0]

            if h0 <= 111 and h0 >= 0 and w0 <= 111 and w0 >= 0:
                if nineble_picture[h0][w0] >= 127.5 and nineble_picture[h0][w0] <= 191.25:
                    pixelnum_token[0][pixel.astype(int)] += 3
                elif nineble_picture[h0][w0] >= 79 and nineble_picture[h0][w0] < 127.5:
                    pixelnum_token[0][pixel.astype(int)] += np.ceil(h0 / 10) + np.ceil(w0 / 10)
                elif nineble_picture[h0][w0] > 191.25 and nineble_picture[h0][w0] <= 255:
                    pixelnum_token[0][(pixel - 191).astype(int)] += np.ceil(h0 / 10) + np.ceil(w0 / 10)

            if h0 <= 111 and h0 >= 0 and w0 <= 213 and w0 >= 112:
                if nineble_picture[h0][w0] >= 127.5 and nineble_picture[h0][w0] <= 191.25:
                    pixelnum_token[0][pixel.astype(int)] += 3
                elif nineble_picture[h0][w0] >= 79 and nineble_picture[h0][w0] < 127.5:
                    pixelnum_token[0][pixel.astype(int)] += np.ceil(h0 / 10) - np.floor(w0 / 10) + 12
                elif nineble_picture[h0][w0] > 191.25 and nineble_picture[h0][w0] <= 255:
                    pixelnum_token[0][(pixel - 191).astype(int)] += np.ceil(h0 / 10) - np.floor(w0 / 10) + 12

            if w0 <= 111 and w0 >= 0 and h0 <= 213 and h0 >= 112:
                if nineble_picture[h0][w0] >= 127.5 and nineble_picture[h0][w0] <= 191.25:
                    pixelnum_token[0][pixel.astype(int)] += 3
                elif nineble_picture[h0][w0] >= 79 and nineble_picture[h0][w0] < 127.5:
                    pixelnum_token[0][pixel.astype(int)] += np.ceil(w0 / 10) - np.floor(h0 / 10) + 12
                elif nineble_picture[h0][w0] > 191.25 and nineble_picture[h0][w0] <= 255:
                    pixelnum_token[0][(pixel - 191).astype(int)] += np.ceil(w0 / 10) - np.floor(h0 / 10) + 12

            if w0 <= 213 and w0 >= 112 and h0 <= 213 and h0 >= 112:
                if nineble_picture[h0][w0] >= 127.5 and nineble_picture[h0][w0] <= 191.25:
                    pixelnum_token[0][pixel.astype(int)] += 3
                elif nineble_picture[h0][w0] >= 79 and nineble_picture[h0][w0] < 127.5:
                    pixelnum_token[0][pixel.astype(int)] += -np.ceil(w0 / 10) - np.floor(h0 / 10) + 24
                elif nineble_picture[h0][w0] > 191.25 and nineble_picture[h0][w0] <= 255:
                    pixelnum_token[0][(pixel - 191).astype(int)] += -np.ceil(w0 / 10) - np.floor(h0 / 10) + 24

    if np.max(pixelnum_token) != 0:
        pixelnum_token = (pixelnum_token / np.max(pixelnum_token)) * 255

    final_size = 224

    column_left_num = math.ceil((final_size - w) / 2)
    if column_left_num < 0:
        column_left_num = 0

    column_right_num = final_size - column_left_num - w
    if column_right_num < 0:
        column_right_num = 0

    top_num = math.ceil((final_size - h) / 2)
    if top_num < 0:
        top_num = 0

    bottom_num = final_size - top_num - h
    if bottom_num < 0:
        bottom_num = 0

    column_left = np.zeros((h, column_left_num))
    column_right = np.zeros((h, column_right_num))

    top = np.zeros((top_num, final_size))
    bottom = np.zeros((bottom_num, final_size))

    img_array_after_left = np.append(column_left, nineble_picture, axis=1)
    img_array_after_right = np.append(img_array_after_left, column_right, axis=1)

    img_array_after_top = np.append(top, img_array_after_right, axis=0)
    img_array_final = np.append(img_array_after_top, bottom, axis=0)

    img_array_final = np.append(img_array_final, pixelnum_token, axis=0)
    return img_array_final


def TMSM(onnx_model_path, object_image):
    """Classify the cropped object using the ONNX classification model."""
    session = ort.InferenceSession(onnx_model_path)
    input_name = session.get_inputs()[0].name
    output_name = session.get_outputs()[0].name

    object_image = HEIF(object_image)
    object_image = object_image.astype(np.float32) / 255.0
    object_image = object_image.transpose(0, 1)
    object_image = object_image.reshape(1, 1, 225, 224)
    classification = session.run([output_name], {input_name: object_image})[0]


    return np.argmax(classification)


def main(image_path, detection_model_path, classification_model_path):
    # Load the original image
    image = cv2.imread(image_path,cv2.IMREAD_GRAYSCALE)
    image_1 = cv2.imread(image_path, cv2.IMREAD_COLOR)

    # Perform object detection
    detections = detect_objects(detection_model_path,image_path)


    # Process detections
    for detection in detections:
        x_min, y_min, x_max, y_max= detection

        object_image = image[y_min:y_max, x_min:x_max]

        # Classify the cropped object
        class_id = TMSM(classification_model_path, object_image)

        # Draw bounding box and label on the original image
        color = (57, 56, 255) if class_id == 1 else (160, 164, 250)  # Example colors

        cv2.rectangle(image_1, (x_min, y_min), (x_max, y_max), color, 2)


    # Save or display the image
    cv2.imwrite('output_image.png', image_1)
    cv2.imshow('Detected Image', image_1)
    cv2.waitKey(0)
    cv2.destroyAllWindows()


if __name__ == "__main__":
    main('000013.png', 'lightYOLO.pt', 'TMSM.onnx') #path of picture,yolo model, TMSM model