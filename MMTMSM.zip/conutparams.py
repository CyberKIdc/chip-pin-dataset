import onnx

# load ONNX model
model = onnx.load("TMSM.onnx")  #  ONNX model path

initializers = model.graph.initializer

# conut
total_params = 0
for initializer in initializers:
    param_count = 1
    for dim in initializer.dims:
        param_count *= dim
    total_params += param_count

print(f"Total number of parameters: {total_params}")