import os
import random
import shutil
from shutil import copy2


def data_take_split(data_folder, take_data_folder, label_folder, label_take_folder, train_scales=0.8, val_scales=0.1,
                    test_scales=0.1):
    """
                                train    val       test
                                0.8      0.1       0.1
    """
    print('start')

    picture_names = os.listdir(data_folder)  # load
    label_names = os.listdir(label_folder)

    take_names = ['train', 'val', 'test']  # create folders
    for take_name in take_names:
        take_path = os.path.join(take_data_folder, take_name)
        if os.path.isdir(take_path):
            pass
        else:
            os.mkdir(take_path)

    for take_name in take_names:
        take_path = os.path.join(label_take_folder, take_name)
        if os.path.isdir(take_path):
            pass
        else:
            os.mkdir(take_path)

    # devide

    train_folder = os.path.join(take_data_folder, 'train')  # train,images
    val_folder = os.path.join(take_data_folder, 'val')
    test_folder = os.path.join(take_data_folder, 'test')

    label_train_folder = os.path.join(label_take_folder, 'train')  # train,labels
    label_val_folder = os.path.join(label_take_folder, 'val')
    label_test_folder = os.path.join(label_take_folder, 'test')

    current_data_length = len(picture_names)
    current_data_index_list = list(range(current_data_length))
    random.shuffle(current_data_index_list)

    train_stop_flage = current_data_length * train_scales
    val_stop_flage = current_data_length * (train_scales + val_scales)

    current_index = 0
    train_num = 0
    val_num = 0
    test_num = 0

    for i in current_data_index_list:
        current_img_path = os.path.join(data_folder, picture_names[i])
        current_label_path = os.path.join(label_folder, label_names[i])

        if current_index <= train_stop_flage:
            copy2(current_img_path, train_folder)
            copy2(current_label_path, label_train_folder)
            train_num += 1

        elif current_index <= val_stop_flage:
            copy2(current_img_path, val_folder)
            copy2(current_label_path, label_val_folder)
            val_num += 1

        else:
            copy2(current_img_path, test_folder)
            copy2(current_label_path, label_test_folder)
            test_num += 1

        current_index += 1

        print('train', train_num)
        print('val', val_num)
        print('test', test_num)


if __name__ == '__main__':
    data_folder = ''  # oringinal path of images
    take_data_folder = ''  # target path of images
    label_folder = ''  # oringinal path of labels
    take_label_folder = ''  # target path of labels

    data_take_split(data_folder, take_data_folder, label_folder, take_label_folder)

